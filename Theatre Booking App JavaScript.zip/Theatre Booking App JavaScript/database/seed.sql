USE theatre_booking;

DELETE FROM reservation_seats;
DELETE FROM reservations;
DELETE FROM showtime_seats;
DELETE FROM showtimes;
DELETE FROM shows;
DELETE FROM theatres;
DELETE FROM refresh_tokens;
DELETE FROM users;

INSERT INTO users (full_name, email, password_hash)
VALUES ('Demo User', 'demo@example.com', '$2b$12$qH09PGJMh9dZJRby.0NoFeFnC3Hs8qM4YnVBXRIkAUs/PiXNckP6W');

INSERT INTO theatres (name, location, description, image_url) VALUES
('Athens City Theatre', 'Athens', 'Modern city theatre with premium main hall.', 'https://example.com/theatre1.jpg'),
('Piraeus Grand Stage', 'Piraeus', 'Historic venue near the port.', 'https://example.com/theatre2.jpg');

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url) VALUES
(1, 'Antigone Reimagined', 'A contemporary interpretation of the classic tragedy.', 125, '12+', 'https://example.com/poster1.jpg'),
(1, 'The Last Letter', 'A drama about memory, loss and reconciliation.', 110, '15+', 'https://example.com/poster2.jpg'),
(2, 'Summer of Shadows', 'Mystery performance with immersive staging.', 100, '12+', 'https://example.com/poster3.jpg');

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status) VALUES
(1, '2026-05-20 20:00:00', 'Main Hall', 18.00, 'AVAILABLE'),
(1, '2026-05-21 20:30:00', 'Main Hall', 18.00, 'AVAILABLE'),
(2, '2026-05-23 19:30:00', 'Studio A', 16.00, 'AVAILABLE'),
(3, '2026-05-24 21:00:00', 'Port Hall', 20.00, 'AVAILABLE');

INSERT INTO showtime_seats (showtime_id, seat_number, row_label, seat_category, price, is_reserved) VALUES
(1,1,'A','VIP',30.00,0),(1,2,'A','VIP',30.00,0),(1,3,'A','VIP',30.00,0),(1,4,'A','VIP',30.00,0),(1,5,'A','VIP',30.00,0),
(1,1,'B','PREMIUM',24.00,0),(1,2,'B','PREMIUM',24.00,0),(1,3,'B','PREMIUM',24.00,0),(1,4,'B','PREMIUM',24.00,0),(1,5,'B','PREMIUM',24.00,0),
(1,1,'C','STANDARD',18.00,0),(1,2,'C','STANDARD',18.00,0),(1,3,'C','STANDARD',18.00,0),(1,4,'C','STANDARD',18.00,0),(1,5,'C','STANDARD',18.00,0),
(1,1,'D','STANDARD',18.00,0),(1,2,'D','STANDARD',18.00,0),(1,3,'D','STANDARD',18.00,0),(1,4,'D','STANDARD',18.00,0),(1,5,'D','STANDARD',18.00,0),
(2,1,'A','VIP',30.00,0),(2,2,'A','VIP',30.00,0),(2,3,'A','VIP',30.00,0),(2,4,'A','VIP',30.00,0),(2,5,'A','VIP',30.00,0),
(2,1,'B','PREMIUM',24.00,0),(2,2,'B','PREMIUM',24.00,0),(2,3,'B','PREMIUM',24.00,0),(2,4,'B','PREMIUM',24.00,0),(2,5,'B','PREMIUM',24.00,0),
(2,1,'C','STANDARD',18.00,0),(2,2,'C','STANDARD',18.00,0),(2,3,'C','STANDARD',18.00,0),(2,4,'C','STANDARD',18.00,0),(2,5,'C','STANDARD',18.00,0),
(2,1,'D','STANDARD',18.00,0),(2,2,'D','STANDARD',18.00,0),(2,3,'D','STANDARD',18.00,0),(2,4,'D','STANDARD',18.00,0),(2,5,'D','STANDARD',18.00,0),
(3,1,'A','VIP',28.00,0),(3,2,'A','VIP',28.00,0),(3,3,'A','VIP',28.00,0),(3,4,'A','VIP',28.00,0),(3,5,'A','VIP',28.00,0),
(3,1,'B','PREMIUM',22.00,0),(3,2,'B','PREMIUM',22.00,0),(3,3,'B','PREMIUM',22.00,0),(3,4,'B','PREMIUM',22.00,0),(3,5,'B','PREMIUM',22.00,0),
(3,1,'C','STANDARD',16.00,0),(3,2,'C','STANDARD',16.00,0),(3,3,'C','STANDARD',16.00,0),(3,4,'C','STANDARD',16.00,0),(3,5,'C','STANDARD',16.00,0),
(4,1,'A','VIP',32.00,0),(4,2,'A','VIP',32.00,0),(4,3,'A','VIP',32.00,0),(4,4,'A','VIP',32.00,0),(4,5,'A','VIP',32.00,0),
(4,1,'B','PREMIUM',25.00,0),(4,2,'B','PREMIUM',25.00,0),(4,3,'B','PREMIUM',25.00,0),(4,4,'B','PREMIUM',25.00,0),(4,5,'B','PREMIUM',25.00,0),
(4,1,'C','STANDARD',20.00,0),(4,2,'C','STANDARD',20.00,0),(4,3,'C','STANDARD',20.00,0),(4,4,'C','STANDARD',20.00,0),(4,5,'C','STANDARD',20.00,0);
