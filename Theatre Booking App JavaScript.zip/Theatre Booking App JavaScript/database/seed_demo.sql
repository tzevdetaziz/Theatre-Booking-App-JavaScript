USE theatre_booking;

SET FOREIGN_KEY_CHECKS = 0;

DELETE FROM reservation_seats;
DELETE FROM reservations;
DELETE FROM showtime_seats;
DELETE FROM showtimes;
DELETE FROM shows;
DELETE FROM theatres;

SET FOREIGN_KEY_CHECKS = 1;

INSERT INTO theatres (name, location, description, image_url) VALUES
('Athens Grand Theatre', 'Athens', 'A premium city-centre venue for major productions and events.', 'https://picsum.photos/seed/athensgrand/900/600'),
('Piraeus City Stage', 'Piraeus', 'Modern performing arts venue near the port with two main halls.', 'https://picsum.photos/seed/piraeusstage/900/600'),
('Thessaloniki Royal Hall', 'Thessaloniki', 'A large northern Greece theatre hosting drama, comedy and musicals.', 'https://picsum.photos/seed/thessroyal/900/600'),
('Patras Cultural Arena', 'Patras', 'A contemporary stage for local and international shows.', 'https://picsum.photos/seed/patrasarena/900/600'),
('Heraklion Open Stage', 'Heraklion', 'A stylish venue with classic and modern productions.', 'https://picsum.photos/seed/heraklionstage/900/600'),
('Larissa Drama House', 'Larissa', 'A well-known regional venue for family and serious theatre.', 'https://picsum.photos/seed/larissahouse/900/600');

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Hamlet Reimagined', 'A modern reinterpretation of Shakespeare''s classic tragedy.', 130, '13+', 'https://picsum.photos/seed/hamlet/500/700'
FROM theatres WHERE name = 'Athens Grand Theatre';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Midnight Mystery', 'A suspense-driven stage production with cinematic atmosphere.', 110, '16+', 'https://picsum.photos/seed/midnightmystery/500/700'
FROM theatres WHERE name = 'Athens Grand Theatre';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Laugh Lines', 'A light-hearted comedy for a broad audience.', 95, '7+', 'https://picsum.photos/seed/laughlines/500/700'
FROM theatres WHERE name = 'Piraeus City Stage';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'The Last Letter', 'A dramatic performance about memory, loss and reconciliation.', 105, '12+', 'https://picsum.photos/seed/lastletter/500/700'
FROM theatres WHERE name = 'Piraeus City Stage';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Comedy of Errors', 'A fast-paced adaptation of mistaken identity and absurd situations.', 100, '7+', 'https://picsum.photos/seed/comedyerrors/500/700'
FROM theatres WHERE name = 'Thessaloniki Royal Hall';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Echoes of War', 'A historical drama with strong emotional storytelling.', 125, '15+', 'https://picsum.photos/seed/echoeswar/500/700'
FROM theatres WHERE name = 'Thessaloniki Royal Hall';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Mamma Mia Tribute Night', 'A musical-style tribute performance inspired by iconic pop classics.', 115, '10+', 'https://picsum.photos/seed/mammamiatribute/500/700'
FROM theatres WHERE name = 'Patras Cultural Arena';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'The Phantom Night', 'A dark and atmospheric theatrical thriller.', 108, '16+', 'https://picsum.photos/seed/phantomnight/500/700'
FROM theatres WHERE name = 'Patras Cultural Arena';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Family Sunday Show', 'A colourful family-friendly performance for children and parents.', 80, '3+', 'https://picsum.photos/seed/familysunday/500/700'
FROM theatres WHERE name = 'Heraklion Open Stage';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Broken Silence', 'A psychological drama focused on truth and justice.', 118, '15+', 'https://picsum.photos/seed/brokensilence/500/700'
FROM theatres WHERE name = 'Heraklion Open Stage';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Ancient Voices', 'A contemporary production inspired by Greek tragic theatre.', 122, '12+', 'https://picsum.photos/seed/ancientvoices/500/700'
FROM theatres WHERE name = 'Larissa Drama House';

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url)
SELECT id, 'Stand-Up Gala', 'An evening of stand-up, improv and comedy sketches.', 90, '10+', 'https://picsum.photos/seed/standupgala/500/700'
FROM theatres WHERE name = 'Larissa Drama House';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 1 DAY) + INTERVAL 18 HOUR + INTERVAL 30 MINUTE, 'Main Hall', 22.00, 'SCHEDULED'
FROM shows WHERE title = 'Hamlet Reimagined';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 3 DAY) + INTERVAL 20 HOUR, 'Main Hall', 22.00, 'SCHEDULED'
FROM shows WHERE title = 'Hamlet Reimagined';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 2 DAY) + INTERVAL 21 HOUR, 'Studio Hall', 19.00, 'SCHEDULED'
FROM shows WHERE title = 'Midnight Mystery';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 5 DAY) + INTERVAL 19 HOUR + INTERVAL 30 MINUTE, 'Studio Hall', 19.00, 'SCHEDULED'
FROM shows WHERE title = 'Midnight Mystery';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 1 DAY) + INTERVAL 19 HOUR, 'Blue Hall', 16.00, 'SCHEDULED'
FROM shows WHERE title = 'Laugh Lines';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 4 DAY) + INTERVAL 19 HOUR, 'Blue Hall', 16.00, 'SCHEDULED'
FROM shows WHERE title = 'Laugh Lines';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 2 DAY) + INTERVAL 18 HOUR, 'Red Hall', 18.50, 'SCHEDULED'
FROM shows WHERE title = 'The Last Letter';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 6 DAY) + INTERVAL 20 HOUR, 'Red Hall', 18.50, 'SCHEDULED'
FROM shows WHERE title = 'The Last Letter';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 1 DAY) + INTERVAL 20 HOUR + INTERVAL 30 MINUTE, 'Royal Hall', 17.50, 'SCHEDULED'
FROM shows WHERE title = 'Comedy of Errors';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 5 DAY) + INTERVAL 18 HOUR + INTERVAL 30 MINUTE, 'Royal Hall', 17.50, 'SCHEDULED'
FROM shows WHERE title = 'Comedy of Errors';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 3 DAY) + INTERVAL 20 HOUR + INTERVAL 15 MINUTE, 'Royal Hall', 21.00, 'SCHEDULED'
FROM shows WHERE title = 'Echoes of War';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 7 DAY) + INTERVAL 19 HOUR + INTERVAL 45 MINUTE, 'Royal Hall', 21.00, 'SCHEDULED'
FROM shows WHERE title = 'Echoes of War';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 2 DAY) + INTERVAL 19 HOUR + INTERVAL 30 MINUTE, 'Arena Main', 23.00, 'SCHEDULED'
FROM shows WHERE title = 'Mamma Mia Tribute Night';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 8 DAY) + INTERVAL 20 HOUR, 'Arena Main', 23.00, 'SCHEDULED'
FROM shows WHERE title = 'Mamma Mia Tribute Night';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 4 DAY) + INTERVAL 21 HOUR, 'Black Box', 20.00, 'SCHEDULED'
FROM shows WHERE title = 'The Phantom Night';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 9 DAY) + INTERVAL 21 HOUR, 'Black Box', 20.00, 'SCHEDULED'
FROM shows WHERE title = 'The Phantom Night';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 1 DAY) + INTERVAL 17 HOUR, 'Family Hall', 12.00, 'SCHEDULED'
FROM shows WHERE title = 'Family Sunday Show';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 6 DAY) + INTERVAL 12 HOUR, 'Family Hall', 12.00, 'SCHEDULED'
FROM shows WHERE title = 'Family Sunday Show';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 3 DAY) + INTERVAL 19 HOUR, 'Main Stage', 19.50, 'SCHEDULED'
FROM shows WHERE title = 'Broken Silence';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 10 DAY) + INTERVAL 20 HOUR, 'Main Stage', 19.50, 'SCHEDULED'
FROM shows WHERE title = 'Broken Silence';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 2 DAY) + INTERVAL 18 HOUR + INTERVAL 45 MINUTE, 'Drama Hall', 18.00, 'SCHEDULED'
FROM shows WHERE title = 'Ancient Voices';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 7 DAY) + INTERVAL 19 HOUR + INTERVAL 15 MINUTE, 'Drama Hall', 18.00, 'SCHEDULED'
FROM shows WHERE title = 'Ancient Voices';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 5 DAY) + INTERVAL 21 HOUR, 'Comedy Hall', 15.00, 'SCHEDULED'
FROM shows WHERE title = 'Stand-Up Gala';

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status)
SELECT id, DATE_ADD(CURDATE(), INTERVAL 11 DAY) + INTERVAL 21 HOUR, 'Comedy Hall', 15.00, 'SCHEDULED'
FROM shows WHERE title = 'Stand-Up Gala';

INSERT INTO showtime_seats (showtime_id, row_label, seat_number, seat_category, price, is_reserved)
SELECT
  st.id,
  seat_rows.row_label,
  seat_nums.seat_number,
  CASE
    WHEN seat_rows.row_label = 'A' THEN 'VIP'
    WHEN seat_rows.row_label IN ('B', 'C') THEN 'STANDARD'
    ELSE 'ECONOMY'
  END,
  CASE
    WHEN seat_rows.row_label = 'A' THEN st.base_price + 10
    WHEN seat_rows.row_label IN ('B', 'C') THEN st.base_price + 2
    ELSE GREATEST(st.base_price - 2, 8)
  END,
  0
FROM showtimes st
CROSS JOIN (
  SELECT 'A' AS row_label
  UNION ALL SELECT 'B'
  UNION ALL SELECT 'C'
  UNION ALL SELECT 'D'
  UNION ALL SELECT 'E'
) AS seat_rows
CROSS JOIN (
  SELECT 1 AS seat_number
  UNION ALL SELECT 2
  UNION ALL SELECT 3
  UNION ALL SELECT 4
  UNION ALL SELECT 5
  UNION ALL SELECT 6
  UNION ALL SELECT 7
  UNION ALL SELECT 8
  UNION ALL SELECT 9
  UNION ALL SELECT 10
) AS seat_nums;