USE theatre_booking;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reservation_seats;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS showtime_seats;
DROP TABLE IF EXISTS showtimes;
DROP TABLE IF EXISTS shows;
DROP TABLE IF EXISTS theatres;
DROP TABLE IF EXISTS refresh_tokens;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE refresh_tokens (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  token TEXT NOT NULL,
  expires_at DATETIME NOT NULL,
  revoked TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_refresh_tokens_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE theatres (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  location VARCHAR(150) NOT NULL,
  description TEXT NULL,
  image_url VARCHAR(255) NULL
);

CREATE TABLE shows (
  id INT AUTO_INCREMENT PRIMARY KEY,
  theatre_id INT NOT NULL,
  title VARCHAR(150) NOT NULL,
  description TEXT NULL,
  duration_minutes INT NOT NULL,
  age_rating VARCHAR(20) NULL,
  poster_url VARCHAR(255) NULL,
  CONSTRAINT fk_shows_theatre
    FOREIGN KEY (theatre_id) REFERENCES theatres(id) ON DELETE CASCADE
);

CREATE TABLE showtimes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  show_id INT NOT NULL,
  starts_at DATETIME NOT NULL,
  hall_name VARCHAR(100) NOT NULL,
  base_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  status VARCHAR(30) NOT NULL DEFAULT 'SCHEDULED',
  CONSTRAINT fk_showtimes_show
    FOREIGN KEY (show_id) REFERENCES shows(id) ON DELETE CASCADE
);

CREATE TABLE showtime_seats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  showtime_id INT NOT NULL,
  row_label VARCHAR(10) NOT NULL,
  seat_number INT NOT NULL,
  seat_category VARCHAR(30) NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  is_reserved TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT fk_showtime_seats_showtime
    FOREIGN KEY (showtime_id) REFERENCES showtimes(id) ON DELETE CASCADE,
  UNIQUE KEY uq_showtime_seat (showtime_id, row_label, seat_number)
);

CREATE TABLE reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  showtime_id INT NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'CONFIRMED',
  total_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_reservations_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_reservations_showtime
    FOREIGN KEY (showtime_id) REFERENCES showtimes(id) ON DELETE CASCADE
);

CREATE TABLE reservation_seats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  reservation_id INT NOT NULL,
  showtime_seat_id INT NOT NULL,
  price DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_reservation_seats_reservation
    FOREIGN KEY (reservation_id) REFERENCES reservations(id) ON DELETE CASCADE,
  CONSTRAINT fk_reservation_seats_showtime_seat
    FOREIGN KEY (showtime_seat_id) REFERENCES showtime_seats(id) ON DELETE CASCADE,
  UNIQUE KEY uq_reservation_seat (reservation_id, showtime_seat_id)
);

INSERT INTO theatres (name, location, description, image_url) VALUES
('Grand City Theatre', 'Athens', 'A modern theatre venue in the city center.', 'https://picsum.photos/seed/theatre1/800/500'),
('Royal Stage', 'Piraeus', 'Classic performances and contemporary productions.', 'https://picsum.photos/seed/theatre2/800/500');

INSERT INTO shows (theatre_id, title, description, duration_minutes, age_rating, poster_url) VALUES
(1, 'Hamlet', 'A Shakespearean tragedy adapted for a modern audience.', 130, '13+', 'https://picsum.photos/seed/show1/500/700'),
(1, 'The Phantom Night', 'A suspense theatre production with dramatic lighting and music.', 110, '16+', 'https://picsum.photos/seed/show2/500/700'),
(2, 'Comedy of Errors', 'A fast-paced comedy performance for all ages.', 95, '7+', 'https://picsum.photos/seed/show3/500/700');

INSERT INTO showtimes (show_id, starts_at, hall_name, base_price, status) VALUES
(1, DATE_ADD(NOW(), INTERVAL 1 DAY), 'Hall A', 18.00, 'SCHEDULED'),
(1, DATE_ADD(NOW(), INTERVAL 3 DAY), 'Hall A', 18.00, 'SCHEDULED'),
(2, DATE_ADD(NOW(), INTERVAL 2 DAY), 'Hall B', 16.50, 'SCHEDULED'),
(3, DATE_ADD(NOW(), INTERVAL 4 DAY), 'Main Stage', 20.00, 'SCHEDULED');

INSERT INTO showtime_seats (showtime_id, row_label, seat_number, seat_category, price, is_reserved)
SELECT
  st.id,
  r.row_label,
  n.seat_number,
  CASE
    WHEN r.row_label = 'A' THEN 'VIP'
    WHEN r.row_label = 'B' THEN 'STANDARD'
    ELSE 'ECONY'
  END,
  CASE
    WHEN r.row_label = 'A' THEN st.base_price + 8
    WHEN r.row_label = 'B' THEN st.base_price
    ELSE GREATEST(st.base_price - 2, 5)
  END,
  0
FROM showtimes st
CROSS JOIN (
  SELECT 'A' AS row_label
  UNION ALL SELECT 'B'
  UNION ALL SELECT 'C'
) r
CROSS JOIN (
  SELECT 1 AS seat_number
  UNION ALL SELECT 2
  UNION ALL SELECT 3
  UNION ALL SELECT 4
  UNION ALL SELECT 5
  UNION ALL SELECT 6
  UNION ALL SELECT 7
  UNION ALL SELECT 8
) n;
