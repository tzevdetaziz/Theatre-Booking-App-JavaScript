const { verifyAccessToken } = require('../utils/jwt');
const ApiError = require('../utils/apiError');

function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return next(new ApiError(401, 'Authentication required.'));
  }
  try {
    req.user = verifyAccessToken(header.split(' ')[1]);
    next();
  } catch (error) {
    next(new ApiError(401, 'Invalid or expired token.'));
  }
}
module.exports = { requireAuth };
