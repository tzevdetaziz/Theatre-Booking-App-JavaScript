const { validationResult } = require('express-validator');
const ApiError = require('../utils/apiError');

function validateRequest(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return next(new ApiError(400, errors.array().map((e) => e.msg).join(' ')));
  }
  next();
}
module.exports = validateRequest;
