const { pool } = require('../config/db');

async function listSeats(req, res, next) {
  try {
    const [rows] = await pool.query(
      `SELECT id, showtime_id AS showtimeId, row_label AS rowLabel, seat_number AS seatNumber,
              seat_category AS seatCategory, price, is_reserved AS isReserved
       FROM showtime_seats
       WHERE showtime_id = ?
       ORDER BY row_label ASC, seat_number ASC`,
      [req.query.showtimeId]
    );
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

module.exports = { listSeats };
