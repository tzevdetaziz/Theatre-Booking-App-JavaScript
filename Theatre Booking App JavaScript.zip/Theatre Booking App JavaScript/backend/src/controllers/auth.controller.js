const { registerUser, loginUser, refreshUserToken, logoutUser } = require('../services/auth.service');

async function register(req, res, next) {
  try {
    const user = await registerUser(req.body);
    res.status(201).json({ success: true, data: user });
  } catch (error) { next(error); }
}

async function login(req, res, next) {
  try {
    const result = await loginUser(req.body);
    res.json({ success: true, data: result });
  } catch (error) { next(error); }
}

async function refresh(req, res, next) {
  try {
    const result = await refreshUserToken(req.body.refreshToken);
    res.json({ success: true, data: result });
  } catch (error) { next(error); }
}

async function logout(req, res, next) {
  try {
    await logoutUser(req.body.refreshToken);
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (error) { next(error); }
}

module.exports = { register, login, refresh, logout };
