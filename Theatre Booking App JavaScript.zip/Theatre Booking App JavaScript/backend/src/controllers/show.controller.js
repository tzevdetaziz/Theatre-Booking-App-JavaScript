const { pool } = require('../config/db');

async function listShows(req, res, next) {
  try {
    const { theatreId, title, date } = req.query;
    let query = `
      SELECT DISTINCT
        s.id,
        s.theatre_id AS theatreId,
        t.name AS theatreName,
        s.title,
        s.description,
        s.duration_minutes AS durationMinutes,
        s.age_rating AS ageRating,
        s.poster_url AS posterUrl
      FROM shows s
      JOIN theatres t ON t.id = s.theatre_id
      LEFT JOIN showtimes st ON st.show_id = s.id
      WHERE 1 = 1`;
    const params = [];
    if (theatreId) { query += ' AND s.theatre_id = ?'; params.push(theatreId); }
    if (title) { query += ' AND s.title LIKE ?'; params.push(`%${title}%`); }
    if (date) { query += ' AND DATE(st.starts_at) = ?'; params.push(date); }
    query += ' ORDER BY s.title ASC';
    const [rows] = await pool.query(query, params);
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

async function getShowById(req, res, next) {
  try {
    const [rows] = await pool.query(
      `SELECT s.id, s.theatre_id AS theatreId, t.name AS theatreName, s.title, s.description,
              s.duration_minutes AS durationMinutes, s.age_rating AS ageRating, s.poster_url AS posterUrl
       FROM shows s JOIN theatres t ON t.id = s.theatre_id WHERE s.id = ?`,
      [req.params.id]
    );
    res.json({ success: true, data: rows[0] || null });
  } catch (error) { next(error); }
}

module.exports = { listShows, getShowById };
