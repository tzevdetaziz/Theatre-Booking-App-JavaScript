const { pool } = require('../config/db');

async function listTheatres(req, res, next) {
  try {
    const { location, name } = req.query;
    let query = 'SELECT id, name, location, description, image_url FROM theatres WHERE 1 = 1';
    const params = [];
    if (location) { query += ' AND location LIKE ?'; params.push(`%${location}%`); }
    if (name) { query += ' AND name LIKE ?'; params.push(`%${name}%`); }
    query += ' ORDER BY name ASC';
    const [rows] = await pool.query(query, params);
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

module.exports = { listTheatres };
