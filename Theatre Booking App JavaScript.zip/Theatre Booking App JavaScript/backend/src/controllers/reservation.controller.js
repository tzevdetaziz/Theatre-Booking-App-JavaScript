const { pool } = require('../config/db');
const { createReservation, cancelReservation, updateReservation } = require('../services/reservation.service');

async function create(req, res, next) {
  try {
    const result = await createReservation({
      userId: req.user.sub,
      showtimeId: req.body.showtimeId,
      seatIds: req.body.seatIds
    });
    res.status(201).json({ success: true, data: result });
  } catch (error) { next(error); }
}

async function update(req, res, next) {
  try {
    const result = await updateReservation({
      reservationId: Number(req.params.id),
      userId: req.user.sub,
      newSeatIds: req.body.seatIds
    });
    res.json({ success: true, data: result });
  } catch (error) { next(error); }
}

async function cancel(req, res, next) {
  try {
    await cancelReservation({ reservationId: Number(req.params.id), userId: req.user.sub });
    res.json({ success: true, message: 'Reservation cancelled successfully.' });
  } catch (error) { next(error); }
}

async function listCurrentUserReservations(req, res, next) {
  try {
    const [rows] = await pool.query(
      `SELECT r.id, r.status, r.total_price AS totalPrice, r.created_at AS createdAt, r.updated_at AS updatedAt,
              st.starts_at AS startsAt, st.hall_name AS hallName, s.title, t.name AS theatreName
       FROM reservations r
       JOIN showtimes st ON st.id = r.showtime_id
       JOIN shows s ON s.id = st.show_id
       JOIN theatres t ON t.id = s.theatre_id
       WHERE r.user_id = ?
       ORDER BY st.starts_at DESC`,
      [req.user.sub]
    );

    for (const reservation of rows) {
      const [seatRows] = await pool.query(
        `SELECT ss.id, ss.row_label AS rowLabel, ss.seat_number AS seatNumber, rs.price
         FROM reservation_seats rs
         JOIN showtime_seats ss ON ss.id = rs.showtime_seat_id
         WHERE rs.reservation_id = ?
         ORDER BY ss.row_label ASC, ss.seat_number ASC`,
        [reservation.id]
      );
      reservation.seats = seatRows.map((seat) => ({
        id: seat.id,
        label: `${seat.rowLabel}${seat.seatNumber}`,
        price: Number(seat.price)
      }));
    }

    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

module.exports = { create, update, cancel, listCurrentUserReservations };
