const { pool } = require('../config/db');

async function listShowtimes(req, res, next) {
  try {
    const showId = req.query.showId || null;
    const [rows] = await pool.query(
      `SELECT id, show_id AS showId, starts_at AS startsAt, hall_name AS hallName, base_price AS basePrice, status
       FROM showtimes
       WHERE (? IS NULL OR show_id = ?)
       ORDER BY starts_at ASC`,
      [showId, showId]
    );
    res.json({ success: true, data: rows });
  } catch (error) { next(error); }
}

module.exports = { listShowtimes };
