const { pool } = require('../config/db');

async function getProfile(req, res, next) {
  try {
    const [rows] = await pool.query(
      'SELECT id, full_name AS fullName, email, created_at AS createdAt FROM users WHERE id = ?',
      [req.user.sub]
    );
    res.json({ success: true, data: rows[0] || null });
  } catch (error) { next(error); }
}

module.exports = { getProfile };
