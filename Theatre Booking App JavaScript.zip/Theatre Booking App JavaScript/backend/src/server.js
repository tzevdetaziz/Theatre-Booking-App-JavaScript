const app = require('./app');
const env = require('./config/env');
const { testConnection } = require('./config/db');

async function bootstrap() {
  try {
    await testConnection();
    app.listen(env.port, () => console.log(`Server listening on port ${env.port}`));
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}
bootstrap();
