const express = require('express');
const cors = require('cors');
const env = require('./config/env');
const authRoutes = require('./routes/auth.routes');
const theatreRoutes = require('./routes/theatre.routes');
const showRoutes = require('./routes/show.routes');
const showtimeRoutes = require('./routes/showtime.routes');
const seatRoutes = require('./routes/seat.routes');
const reservationRoutes = require('./routes/reservation.routes');
const userRoutes = require('./routes/user.routes');
const errorHandler = require('./middleware/errorHandler');

const app = express();
app.use(cors({ origin: env.corsOrigin }));
app.use(express.json());

app.get('/health', (req, res) => res.json({ success: true, message: 'API is running.' }));
app.use('/auth', authRoutes);
app.use('/theatres', theatreRoutes);
app.use('/shows', showRoutes);
app.use('/showtimes', showtimeRoutes);
app.use('/seats', seatRoutes);
app.use('/reservations', reservationRoutes);
app.use('/user', userRoutes);
app.use(errorHandler);
module.exports = app;
