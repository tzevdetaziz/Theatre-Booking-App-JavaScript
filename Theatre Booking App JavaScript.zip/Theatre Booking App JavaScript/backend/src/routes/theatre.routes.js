const express = require('express');
const controller = require('../controllers/theatre.controller');
const router = express.Router();
router.get('/', controller.listTheatres);
module.exports = router;
