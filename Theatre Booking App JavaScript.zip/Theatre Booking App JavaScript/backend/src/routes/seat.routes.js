const express = require('express');
const { query } = require('express-validator');
const controller = require('../controllers/seat.controller');
const validateRequest = require('../middleware/validate');
const router = express.Router();
router.get('/', [query('showtimeId').isInt().withMessage('showtimeId must be an integer.')], validateRequest, controller.listSeats);
module.exports = router;
