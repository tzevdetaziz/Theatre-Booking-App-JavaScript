const express = require('express');
const { requireAuth } = require('../middleware/auth');
const { getProfile } = require('../controllers/user.controller');
const { listCurrentUserReservations } = require('../controllers/reservation.controller');
const router = express.Router();
router.use(requireAuth);
router.get('/profile', getProfile);
router.get('/reservations', listCurrentUserReservations);
module.exports = router;
