const express = require('express');
const controller = require('../controllers/showtime.controller');
const router = express.Router();
router.get('/', controller.listShowtimes);
module.exports = router;
