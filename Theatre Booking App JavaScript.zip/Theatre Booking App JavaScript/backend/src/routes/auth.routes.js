const express = require('express');
const { body } = require('express-validator');
const controller = require('../controllers/auth.controller');
const validateRequest = require('../middleware/validate');

const router = express.Router();
router.post('/register', [body('fullName').trim().notEmpty().withMessage('Full name is required.'), body('email').isEmail().withMessage('A valid email is required.'), body('password').isLength({ min: 8 }).withMessage('Password must contain at least 8 characters.')], validateRequest, controller.register);
router.post('/login', [body('email').isEmail().withMessage('A valid email is required.'), body('password').notEmpty().withMessage('Password is required.')], validateRequest, controller.login);
router.post('/refresh', [body('refreshToken').notEmpty().withMessage('Refresh token is required.')], validateRequest, controller.refresh);
router.post('/logout', [body('refreshToken').notEmpty().withMessage('Refresh token is required.')], validateRequest, controller.logout);
module.exports = router;
