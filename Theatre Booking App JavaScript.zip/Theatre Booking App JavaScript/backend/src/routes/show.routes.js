const express = require('express');
const controller = require('../controllers/show.controller');
const router = express.Router();
router.get('/', controller.listShows);
router.get('/:id', controller.getShowById);
module.exports = router;
