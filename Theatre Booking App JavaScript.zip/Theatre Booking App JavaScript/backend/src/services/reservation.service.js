const { pool } = require('../config/db');
const ApiError = require('../utils/apiError');

async function createReservation({ userId, showtimeId, seatIds }) {
  if (!Array.isArray(seatIds) || seatIds.length === 0) {
    throw new ApiError(400, 'At least one seat must be selected.');
  }

  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const placeholders = seatIds.map(() => '?').join(',');
    const [seatRows] = await connection.query(
      `SELECT id, showtime_id, seat_number, row_label, price, is_reserved
       FROM showtime_seats
       WHERE showtime_id = ? AND id IN (${placeholders})
       FOR UPDATE`,
      [showtimeId, ...seatIds]
    );

    if (seatRows.length !== seatIds.length) {
      throw new ApiError(400, 'One or more selected seats do not exist.');
    }

    const reservedSeat = seatRows.find((seat) => seat.is_reserved === 1);
    if (reservedSeat) {
      throw new ApiError(409, `Seat ${reservedSeat.row_label}${reservedSeat.seat_number} is already reserved.`);
    }

    const totalPrice = seatRows.reduce((sum, seat) => sum + Number(seat.price), 0);
    const [reservationResult] = await connection.query(
      `INSERT INTO reservations (user_id, showtime_id, status, total_price)
       VALUES (?, ?, 'CONFIRMED', ?)`,
      [userId, showtimeId, totalPrice]
    );
    const reservationId = reservationResult.insertId;

    for (const seat of seatRows) {
      await connection.query(
        'INSERT INTO reservation_seats (reservation_id, showtime_seat_id, price) VALUES (?, ?, ?)',
        [reservationId, seat.id, seat.price]
      );
      await connection.query('UPDATE showtime_seats SET is_reserved = 1 WHERE id = ?', [seat.id]);
    }

    await connection.commit();
    return {
      reservationId,
      totalPrice,
      seats: seatRows.map((seat) => ({
        id: seat.id,
        label: `${seat.row_label}${seat.seat_number}`,
        price: Number(seat.price)
      }))
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function cancelReservation({ reservationId, userId }) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [reservationRows] = await connection.query(
      `SELECT r.id, r.status, st.starts_at
       FROM reservations r
       JOIN showtimes st ON st.id = r.showtime_id
       WHERE r.id = ? AND r.user_id = ?
       FOR UPDATE`,
      [reservationId, userId]
    );
    const reservation = reservationRows[0];
    if (!reservation) throw new ApiError(404, 'Reservation not found.');
    if (reservation.status === 'CANCELLED') throw new ApiError(400, 'Reservation already cancelled.');
    if (new Date(reservation.starts_at) <= new Date()) throw new ApiError(400, 'Only future reservations can be cancelled.');

    const [reservedSeats] = await connection.query(
      'SELECT showtime_seat_id FROM reservation_seats WHERE reservation_id = ?',
      [reservationId]
    );

    await connection.query("UPDATE reservations SET status = 'CANCELLED' WHERE id = ?", [reservationId]);
    for (const seat of reservedSeats) {
      await connection.query('UPDATE showtime_seats SET is_reserved = 0 WHERE id = ?', [seat.showtime_seat_id]);
    }

    await connection.commit();
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function updateReservation({ reservationId, userId, newSeatIds }) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [reservationRows] = await connection.query(
      `SELECT r.id, r.showtime_id, r.status, st.starts_at
       FROM reservations r
       JOIN showtimes st ON st.id = r.showtime_id
       WHERE r.id = ? AND r.user_id = ?
       FOR UPDATE`,
      [reservationId, userId]
    );
    const reservation = reservationRows[0];
    if (!reservation) throw new ApiError(404, 'Reservation not found.');
    if (reservation.status !== 'CONFIRMED') throw new ApiError(400, 'Only confirmed reservations can be updated.');
    if (new Date(reservation.starts_at) <= new Date()) throw new ApiError(400, 'Only future reservations can be updated.');

    const [currentSeats] = await connection.query('SELECT showtime_seat_id FROM reservation_seats WHERE reservation_id = ?', [reservationId]);
    for (const currentSeat of currentSeats) {
      await connection.query('UPDATE showtime_seats SET is_reserved = 0 WHERE id = ?', [currentSeat.showtime_seat_id]);
    }
    await connection.query('DELETE FROM reservation_seats WHERE reservation_id = ?', [reservationId]);

    const placeholders = newSeatIds.map(() => '?').join(',');
    const [newSeats] = await connection.query(
      `SELECT id, seat_number, row_label, price, is_reserved
       FROM showtime_seats
       WHERE showtime_id = ? AND id IN (${placeholders})
       FOR UPDATE`,
      [reservation.showtime_id, ...newSeatIds]
    );
    if (newSeats.length !== newSeatIds.length) throw new ApiError(400, 'One or more replacement seats do not exist.');

    const alreadyReserved = newSeats.find((seat) => seat.is_reserved === 1);
    if (alreadyReserved) throw new ApiError(409, `Seat ${alreadyReserved.row_label}${alreadyReserved.seat_number} is already reserved.`);

    let totalPrice = 0;
    for (const seat of newSeats) {
      await connection.query(
        'INSERT INTO reservation_seats (reservation_id, showtime_seat_id, price) VALUES (?, ?, ?)',
        [reservationId, seat.id, seat.price]
      );
      await connection.query('UPDATE showtime_seats SET is_reserved = 1 WHERE id = ?', [seat.id]);
      totalPrice += Number(seat.price);
    }

    await connection.query('UPDATE reservations SET total_price = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', [totalPrice, reservationId]);
    await connection.commit();
    return { reservationId, totalPrice };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = { createReservation, cancelReservation, updateReservation };
