const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const ApiError = require('../utils/apiError');
const { signAccessToken, signRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const env = require('../config/env');

function getRefreshExpiryDate() {
  const date = new Date();
  date.setDate(date.getDate() + env.jwt.refreshExpiresInDays);
  return date;
}

async function registerUser({ fullName, email, password }) {
  const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (existing.length > 0) throw new ApiError(409, 'Email already registered.');

  const passwordHash = await bcrypt.hash(password, 12);
  const [result] = await pool.query(
    'INSERT INTO users (full_name, email, password_hash) VALUES (?, ?, ?)',
    [fullName, email, passwordHash]
  );

  return { id: result.insertId, fullName, email };
}

async function loginUser({ email, password }) {
  const [rows] = await pool.query(
    'SELECT id, full_name, email, password_hash FROM users WHERE email = ?',
    [email]
  );
  const user = rows[0];
  if (!user) throw new ApiError(401, 'Invalid email or password.');

  const matches = await bcrypt.compare(password, user.password_hash);
  if (!matches) throw new ApiError(401, 'Invalid email or password.');

  const payload = { sub: user.id, email: user.email, fullName: user.full_name };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken({ sub: user.id });

  await pool.query(
    'INSERT INTO refresh_tokens (user_id, token, expires_at, revoked) VALUES (?, ?, ?, 0)',
    [user.id, refreshToken, getRefreshExpiryDate()]
  );

  return {
    user: { id: user.id, fullName: user.full_name, email: user.email },
    accessToken,
    refreshToken
  };
}

async function refreshUserToken(refreshToken) {
  try {
    verifyRefreshToken(refreshToken);
  } catch (error) {
    throw new ApiError(401, 'Invalid refresh token.');
  }

  const [rows] = await pool.query(
    `SELECT rt.user_id, rt.expires_at, rt.revoked, u.email, u.full_name
     FROM refresh_tokens rt
     JOIN users u ON u.id = rt.user_id
     WHERE rt.token = ?`,
    [refreshToken]
  );
  const tokenRow = rows[0];
  if (!tokenRow || tokenRow.revoked) throw new ApiError(401, 'Refresh token not active.');
  if (new Date(tokenRow.expires_at) < new Date()) throw new ApiError(401, 'Refresh token expired.');

  return {
    accessToken: signAccessToken({
      sub: tokenRow.user_id,
      email: tokenRow.email,
      fullName: tokenRow.full_name
    })
  };
}

async function logoutUser(refreshToken) {
  await pool.query('UPDATE refresh_tokens SET revoked = 1 WHERE token = ?', [refreshToken]);
}

module.exports = { registerUser, loginUser, refreshUserToken, logoutUser };
