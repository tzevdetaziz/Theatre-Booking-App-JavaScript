import React, { useState } from 'react';
import { Alert, StyleSheet, Text, TextInput, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import PrimaryButton from '../components/PrimaryButton';
import colors from '../theme/colors';
import { useAuth } from '../context/AuthContext';

export default function LoginScreen({ navigation }) {
  const { signIn } = useAuth();
  const [email, setEmail] = useState('demo@example.com');
  const [password, setPassword] = useState('Password123!');
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    try {
      setLoading(true);
      await signIn(email, password);
    } catch (error) {
      Alert.alert('Login failed', error.response?.data?.message || 'Please check your credentials.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScreenContainer style={styles.container}>
      <View style={styles.hero}>
        <Text style={styles.title}>Theatre Booking</Text>
        <Text style={styles.subtitle}>Sign in to browse performances and reserve seats.</Text>
      </View>
      <TextInput style={styles.input} placeholder="Email" autoCapitalize="none" value={email} onChangeText={setEmail} />
      <TextInput style={styles.input} placeholder="Password" secureTextEntry value={password} onChangeText={setPassword} />
      <PrimaryButton title={loading ? 'Signing in...' : 'Login'} onPress={handleLogin} disabled={loading} />
      <View style={styles.footer}><Text style={styles.footerText}>No account yet?</Text><Text style={styles.link} onPress={() => navigation.navigate('Register')}>Create one</Text></View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20, justifyContent: 'center' },
  hero: { marginBottom: 28 },
  title: { fontSize: 30, fontWeight: '800', color: colors.primary, marginBottom: 8 },
  subtitle: { fontSize: 15, color: colors.textMuted },
  input: { backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: colors.border, paddingHorizontal: 14, paddingVertical: 14, marginBottom: 14 },
  footer: { marginTop: 18, flexDirection: 'row', gap: 6 },
  footerText: { color: colors.textMuted },
  link: { color: colors.primary, fontWeight: '700' }
});
