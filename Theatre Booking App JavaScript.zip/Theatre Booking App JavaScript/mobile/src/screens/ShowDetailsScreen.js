import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import colors from '../theme/colors';
import { getShowtimes } from '../services/api';

export default function ShowDetailsScreen({ route, navigation }) {
  const show = route.params?.show;
  const [showtimes, setShowtimes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    navigation.setOptions({ title: show?.title || 'Show Details' });
    async function loadShowtimes() {
      try {
        setLoading(true);
        const data = await getShowtimes(show.id);
        setShowtimes(data);
      } finally { setLoading(false); }
    }
    loadShowtimes();
  }, []);

  return (
    <ScreenContainer>
      <View style={styles.container}>
        <View style={styles.heroCard}>
          <Text style={styles.title}>{show.title}</Text>
          <Text style={styles.meta}>{show.durationMinutes} min · {show.ageRating}</Text>
          <Text style={styles.description}>{show.description}</Text>
        </View>
        <Text style={styles.sectionTitle}>Available showtimes</Text>
        {loading ? <ActivityIndicator style={{ marginTop: 24 }} size="large" /> : (
          <FlatList
            data={showtimes}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => (
              <Pressable style={styles.showtimeCard} onPress={() => navigation.navigate('SeatSelection', { show, showtime: item })}>
                <Text style={styles.showtimeTitle}>{new Date(item.startsAt).toLocaleString()}</Text>
                <Text style={styles.showtimeText}>Hall: {item.hallName} · Base price: €{Number(item.basePrice).toFixed(2)}</Text>
              </Pressable>
            )}
          />
        )}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, flex: 1 },
  heroCard: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 16, borderWidth: 1, borderColor: colors.border, marginBottom: 16 },
  title: { fontSize: 22, fontWeight: '800', color: colors.primary },
  meta: { marginTop: 8, color: colors.accent, fontWeight: '700' },
  description: { marginTop: 10, color: colors.textMuted, lineHeight: 20 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: colors.text, marginBottom: 10 },
  showtimeCard: { backgroundColor: '#FFFFFF', borderRadius: 16, padding: 15, marginBottom: 10, borderWidth: 1, borderColor: colors.border },
  showtimeTitle: { fontWeight: '800', color: colors.text },
  showtimeText: { marginTop: 6, color: colors.textMuted }
});
