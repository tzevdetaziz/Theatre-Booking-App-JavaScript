import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import SearchInput from '../components/SearchInput';
import colors from '../theme/colors';
import { getShows } from '../services/api';

export default function ShowListScreen({ route, navigation }) {
  const theatre = route.params?.theatre;
  const [title, setTitle] = useState('');
  const [shows, setShows] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadShows() {
    try {
      setLoading(true);
      const data = await getShows({ theatreId: theatre?.id, title });
      setShows(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    navigation.setOptions({ title: theatre?.name || 'Shows' });
    loadShows();
  }, []);

  return (
    <ScreenContainer>
      <View style={styles.container}>
        <Text style={styles.heading}>{theatre?.name}</Text>
        <Text style={styles.subheading}>Select a performance</Text>
        <SearchInput value={title} onChangeText={setTitle} placeholder="Search by title" />
        <Pressable style={styles.searchButton} onPress={loadShows}><Text style={styles.searchButtonText}>Filter</Text></Pressable>
        {loading ? <ActivityIndicator style={{ marginTop: 32 }} size="large" /> : (
          <FlatList
            data={shows}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => (
              <Pressable style={styles.card} onPress={() => navigation.navigate('ShowDetails', { show: item })}>
                <Text style={styles.cardTitle}>{item.title}</Text>
                <Text style={styles.meta}>{item.durationMinutes} min · {item.ageRating}</Text>
                <Text style={styles.description}>{item.description}</Text>
              </Pressable>
            )}
          />
        )}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, flex: 1 },
  heading: { fontSize: 24, fontWeight: '800', color: colors.primary },
  subheading: { color: colors.textMuted, marginBottom: 14 },
  searchButton: { backgroundColor: colors.secondary, paddingVertical: 12, borderRadius: 12, alignItems: 'center', marginBottom: 14 },
  searchButtonText: { color: '#FFFFFF', fontWeight: '700' },
  card: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  cardTitle: { fontSize: 18, fontWeight: '800', color: colors.text },
  meta: { color: colors.accent, marginTop: 6, fontWeight: '700' },
  description: { marginTop: 10, color: colors.textMuted, lineHeight: 20 }
});
