import React, { useEffect, useMemo, useState } from 'react';
import { Alert, FlatList, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import PrimaryButton from '../components/PrimaryButton';
import colors from '../theme/colors';
import { createReservation, getSeats } from '../services/api';

function groupSeatsByRow(seats) {
  return seats.reduce((acc, seat) => {
    if (!acc[seat.rowLabel]) acc[seat.rowLabel] = [];
    acc[seat.rowLabel].push(seat);
    return acc;
  }, {});
}

export default function SeatSelectionScreen({ route, navigation }) {
  const { show, showtime } = route.params;
  const [seats, setSeats] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [loadingReservation, setLoadingReservation] = useState(false);

  useEffect(() => {
    async function loadSeats() {
      const data = await getSeats(showtime.id);
      setSeats(data);
    }
    loadSeats();
  }, [showtime.id]);

  function toggleSeat(seat) {
    if (seat.isReserved) return;
    setSelectedIds((current) => current.includes(seat.id) ? current.filter((id) => id !== seat.id) : [...current, seat.id]);
  }

  async function handleReservation() {
    try {
      setLoadingReservation(true);
      const result = await createReservation({ showtimeId: showtime.id, seatIds: selectedIds });
      Alert.alert('Reservation confirmed', `Reservation #${result.reservationId} completed successfully.`);
      navigation.navigate('Theatres');
    } catch (error) {
      Alert.alert('Reservation failed', error.response?.data?.message || 'Please try different seats.');
    } finally {
      setLoadingReservation(false);
    }
  }

  const grouped = useMemo(() => groupSeatsByRow(seats), [seats]);
  const selectedSeats = seats.filter((seat) => selectedIds.includes(seat.id));
  const total = selectedSeats.reduce((sum, seat) => sum + Number(seat.price), 0);

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>{show.title}</Text>
        <Text style={styles.subheading}>{new Date(showtime.startsAt).toLocaleString()}</Text>
        <View style={styles.legend}><Legend color={colors.primary} label="Available" /><Legend color={colors.selected} label="Selected" /><Legend color={colors.reserved} label="Reserved" /></View>
        <View style={styles.screenMark}><Text style={styles.screenText}>STAGE</Text></View>
        {Object.keys(grouped).map((rowLabel) => (
          <View key={rowLabel} style={styles.rowContainer}>
            <Text style={styles.rowLabel}>{rowLabel}</Text>
            <FlatList
              horizontal
              data={grouped[rowLabel]}
              keyExtractor={(item) => String(item.id)}
              renderItem={({ item }) => {
                const isSelected = selectedIds.includes(item.id);
                const backgroundColor = item.isReserved ? colors.reserved : isSelected ? colors.selected : colors.primary;
                return <Pressable onPress={() => toggleSeat(item)} style={[styles.seat, { backgroundColor }]}><Text style={styles.seatText}>{item.seatNumber}</Text></Pressable>;
              }}
              showsHorizontalScrollIndicator={false}
            />
          </View>
        ))}
        <View style={styles.summaryCard}>
          <Text style={styles.summaryTitle}>Booking summary</Text>
          <Text style={styles.summaryText}>Selected seats: {selectedSeats.length ? selectedSeats.map((seat) => `${seat.rowLabel}${seat.seatNumber}`).join(', ') : 'None'}</Text>
          <Text style={styles.summaryText}>Total: €{total.toFixed(2)}</Text>
        </View>
        <PrimaryButton title={loadingReservation ? 'Processing...' : 'Confirm Reservation'} onPress={handleReservation} disabled={!selectedIds.length || loadingReservation} />
      </ScrollView>
    </ScreenContainer>
  );
}

function Legend({ color, label }) {
  return <View style={styles.legendItem}><View style={[styles.legendDot, { backgroundColor: color }]} /><Text style={styles.legendText}>{label}</Text></View>;
}

const styles = StyleSheet.create({
  container: { padding: 16, paddingBottom: 30 },
  heading: { fontSize: 22, fontWeight: '800', color: colors.primary },
  subheading: { color: colors.textMuted, marginBottom: 14 },
  legend: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 18 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  legendDot: { width: 14, height: 14, borderRadius: 7 },
  legendText: { color: colors.textMuted },
  screenMark: { alignSelf: 'center', backgroundColor: '#DDE7F7', borderRadius: 10, paddingHorizontal: 20, paddingVertical: 10, marginBottom: 18 },
  screenText: { color: colors.primary, fontWeight: '800', letterSpacing: 1.5 },
  rowContainer: { marginBottom: 14 },
  rowLabel: { marginBottom: 8, fontWeight: '800', color: colors.text },
  seat: { width: 44, height: 44, borderRadius: 12, marginRight: 8, alignItems: 'center', justifyContent: 'center' },
  seatText: { color: '#FFFFFF', fontWeight: '800' },
  summaryCard: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 16, borderWidth: 1, borderColor: colors.border, marginTop: 8, marginBottom: 16 },
  summaryTitle: { fontSize: 18, fontWeight: '800', color: colors.text, marginBottom: 10 },
  summaryText: { color: colors.textMuted, lineHeight: 22 }
});
