import React, { useCallback, useState } from 'react';
import { Alert, FlatList, Pressable, RefreshControl, StyleSheet, Text, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import colors from '../theme/colors';
import { cancelReservation, getMyReservations } from '../services/api';

export default function ReservationsScreen() {
  const [reservations, setReservations] = useState([]);
  const [refreshing, setRefreshing] = useState(false);

  const loadReservations = useCallback(async () => {
    try {
      setRefreshing(true);
      const data = await getMyReservations();
      setReservations(data);
    } finally {
      setRefreshing(false);
    }
  }, []);

  React.useEffect(() => {
    loadReservations();
  }, [loadReservations]);

  async function handleCancel(id) {
    try {
      await cancelReservation(id);
      Alert.alert('Reservation cancelled');
      loadReservations();
    } catch (error) {
      Alert.alert('Cancellation failed', error.response?.data?.message || 'Unable to cancel reservation.');
    }
  }

  return (
    <ScreenContainer edges={['top', 'left', 'right']}>
      <View style={styles.container}>
        <Text style={styles.title}>My Reservations</Text>
        <FlatList
          data={reservations}
          keyExtractor={(item) => String(item.id)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={loadReservations} />}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>{item.title}</Text>
              <Text style={styles.cardSubtitle}>{item.theatreName}</Text>
              <Text style={styles.cardText}>{new Date(item.startsAt).toLocaleString()}</Text>
              <Text style={styles.cardText}>Seats: {item.seats.map((seat) => seat.label).join(', ')}</Text>
              <Text style={styles.cardText}>Total: €{Number(item.totalPrice).toFixed(2)}</Text>
              <Text style={[styles.badge, item.status === 'CONFIRMED' ? styles.confirmed : styles.cancelled]}>{item.status}</Text>
              {item.status === 'CONFIRMED' && new Date(item.startsAt) > new Date() && (
                <Pressable style={styles.cancelButton} onPress={() => handleCancel(item.id)}>
                  <Text style={styles.cancelButtonText}>Cancel reservation</Text>
                </Pressable>
              )}
            </View>
          )}
          contentContainerStyle={reservations.length ? styles.listContent : styles.emptyContent}
          ListEmptyComponent={<Text style={styles.empty}>No reservations found.</Text>}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, paddingTop: 10, flex: 1 },
  title: { fontSize: 24, fontWeight: '800', color: colors.primary, marginBottom: 16 },
  listContent: { paddingBottom: 20 },
  emptyContent: { paddingBottom: 20 },
  card: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  cardTitle: { fontSize: 18, fontWeight: '800', color: colors.text },
  cardSubtitle: { marginTop: 4, color: colors.accent, fontWeight: '700' },
  cardText: { marginTop: 6, color: colors.textMuted },
  badge: { marginTop: 10, alignSelf: 'flex-start', borderRadius: 999, paddingVertical: 6, paddingHorizontal: 12, fontWeight: '800', overflow: 'hidden' },
  confirmed: { backgroundColor: '#DCFCE7', color: '#166534' },
  cancelled: { backgroundColor: '#FEE2E2', color: '#991B1B' },
  cancelButton: { marginTop: 12, backgroundColor: colors.danger, paddingVertical: 12, borderRadius: 12, alignItems: 'center' },
  cancelButtonText: { color: '#FFFFFF', fontWeight: '700' },
  empty: { color: colors.textMuted }
});
