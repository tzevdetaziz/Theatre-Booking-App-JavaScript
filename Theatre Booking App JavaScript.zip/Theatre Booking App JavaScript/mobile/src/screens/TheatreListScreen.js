import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import SearchInput from '../components/SearchInput';
import colors from '../theme/colors';
import { getTheatres } from '../services/api';

function TheatreCard({ item, onPress }) {
  return (
    <Pressable style={styles.card} onPress={onPress}>
      <Text style={styles.cardTitle}>{item.name}</Text>
      <Text style={styles.cardSubtitle}>{item.location}</Text>
      <Text style={styles.cardText}>{item.description}</Text>
    </Pressable>
  );
}

export default function TheatreListScreen({ navigation }) {
  const [query, setQuery] = useState('');
  const [theatres, setTheatres] = useState([]);
  const [loading, setLoading] = useState(true);

  async function loadTheatres() {
    try {
      setLoading(true);
      const data = await getTheatres({ name: query, location: query });
      setTheatres(data);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadTheatres(); }, []);

  return (
    <ScreenContainer>
      <View style={styles.container}>
        <Text style={styles.title}>Available Theatres</Text>
        <SearchInput value={query} onChangeText={setQuery} placeholder="Search by theatre or location" />
        <Pressable style={styles.searchButton} onPress={loadTheatres}><Text style={styles.searchButtonText}>Search</Text></Pressable>
        {loading ? <ActivityIndicator style={{ marginTop: 32 }} size="large" /> : (
          <FlatList
            data={theatres}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => <TheatreCard item={item} onPress={() => navigation.navigate('Shows', { theatre: item })} />}
            contentContainerStyle={{ paddingBottom: 20 }}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, flex: 1 },
  title: { fontSize: 24, fontWeight: '800', color: colors.primary, marginBottom: 14 },
  searchButton: { backgroundColor: colors.secondary, paddingVertical: 12, borderRadius: 12, alignItems: 'center', marginBottom: 14 },
  searchButtonText: { color: '#FFFFFF', fontWeight: '700' },
  card: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: colors.border },
  cardTitle: { fontSize: 18, fontWeight: '800', color: colors.text },
  cardSubtitle: { marginTop: 4, color: colors.accent, fontWeight: '700' },
  cardText: { marginTop: 10, color: colors.textMuted, lineHeight: 20 }
});
