import React, { useEffect, useState } from 'react';
import { Alert, StyleSheet, Text, View } from 'react-native';
import ScreenContainer from '../components/ScreenContainer';
import PrimaryButton from '../components/PrimaryButton';
import colors from '../theme/colors';
import { getMyProfile } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function ProfileScreen() {
  const { signOut } = useAuth();
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    async function loadProfile() {
      try {
        setProfile(await getMyProfile());
      } catch (error) {
        Alert.alert('Profile error', 'Unable to load profile.');
      }
    }

    loadProfile();
  }, []);

  return (
    <ScreenContainer edges={['top', 'left', 'right']}>
      <View style={styles.container}>
        <Text style={styles.title}>Profile</Text>
        <View style={styles.card}>
          <Text style={styles.label}>Full name</Text>
          <Text style={styles.value}>{profile?.fullName || '-'}</Text>
          <Text style={styles.label}>Email</Text>
          <Text style={styles.value}>{profile?.email || '-'}</Text>
          <Text style={styles.label}>Member since</Text>
          <Text style={styles.value}>{profile?.createdAt ? new Date(profile.createdAt).toLocaleDateString() : '-'}</Text>
        </View>
        <PrimaryButton title="Logout" onPress={signOut} variant="secondary" />
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { padding: 16, paddingTop: 10, flex: 1 },
  title: { fontSize: 24, fontWeight: '800', color: colors.primary, marginBottom: 16 },
  card: { backgroundColor: '#FFFFFF', borderRadius: 18, padding: 18, borderWidth: 1, borderColor: colors.border, marginBottom: 16 },
  label: { color: colors.textMuted, marginTop: 10 },
  value: { fontSize: 17, fontWeight: '700', color: colors.text }
});
