export default {
  background: '#F6F8FC',
  card: '#FFFFFF',
  primary: '#1C2541',
  secondary: '#3A506B',
  accent: '#5BC0BE',
  success: '#2D6A4F',
  danger: '#C1121F',
  text: '#17212B',
  textMuted: '#667085',
  border: '#D0D5DD',
  selected: '#1D4ED8',
  reserved: '#9CA3AF'
};
