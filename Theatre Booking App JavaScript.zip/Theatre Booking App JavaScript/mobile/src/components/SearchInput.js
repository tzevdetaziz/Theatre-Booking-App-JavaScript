import React from 'react';
import { StyleSheet, TextInput, View } from 'react-native';
import colors from '../theme/colors';

export default function SearchInput({ value, onChangeText, placeholder }) {
  return (
    <View style={styles.container}>
      <TextInput placeholder={placeholder} placeholderTextColor={colors.textMuted} style={styles.input} value={value} onChangeText={onChangeText} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { backgroundColor: '#FFFFFF', borderRadius: 14, borderWidth: 1, borderColor: colors.border, marginBottom: 14 },
  input: { paddingHorizontal: 14, paddingVertical: 13, color: colors.text }
});
