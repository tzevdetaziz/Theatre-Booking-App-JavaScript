import React from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import colors from '../theme/colors';

export default function PrimaryButton({ title, onPress, disabled = false, variant = 'primary' }) {
  const variantStyle = variant === 'secondary' ? styles.secondary : styles.primary;
  return (
    <Pressable style={[styles.button, variantStyle, disabled && styles.disabled]} onPress={onPress} disabled={disabled}>
      <Text style={[styles.text, variant === 'secondary' && styles.secondaryText]}>{title}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: { borderRadius: 14, paddingVertical: 14, alignItems: 'center', justifyContent: 'center' },
  primary: { backgroundColor: colors.primary },
  secondary: { backgroundColor: '#E8EEF9', borderWidth: 1, borderColor: colors.secondary },
  disabled: { opacity: 0.55 },
  text: { color: '#FFFFFF', fontWeight: '700', fontSize: 16 },
  secondaryText: { color: colors.secondary }
});
