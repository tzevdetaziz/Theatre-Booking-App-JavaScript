import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { clearTokens, loadStoredTokens, loginUser, logoutUser as apiLogout, persistTokens } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [booting, setBooting] = useState(true);

  useEffect(() => {
    async function bootstrap() {
      try {
        const tokens = await loadStoredTokens();
        if (tokens.accessToken) setUser({ authenticated: true });
      } finally {
        setBooting(false);
      }
    }
    bootstrap();
  }, []);

  const value = useMemo(() => ({
    user,
    booting,
    isAuthenticated: !!user,
    async signIn(email, password) {
      const result = await loginUser({ email, password });
      await persistTokens(result.accessToken, result.refreshToken);
      setUser(result.user);
      return result.user;
    },
    async signOut() {
      await apiLogout();
      setUser(null);
    },
    async restoreGuestState() {
      await clearTokens();
      setUser(null);
    },
    setUser
  }), [user, booting]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() { return useContext(AuthContext); }
