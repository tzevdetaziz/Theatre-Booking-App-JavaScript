import axios from 'axios';
import { Platform } from 'react-native';
import { getItem, setItem, deleteItem } from './storage';

const BASE_URL =
  Platform.OS === 'web'
    ? 'http://localhost:5000'
    : Platform.OS === 'android'
    ? 'http://192.168.1.3:5000'
    : 'http://localhost:5000';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 10000,
});

let accessToken = null;
let refreshToken = null;

export async function loadStoredTokens() {
  accessToken = await getItem('accessToken');
  refreshToken = await getItem('refreshToken');
  return { accessToken, refreshToken };
}

export async function persistTokens(nextAccessToken, nextRefreshToken) {
  accessToken = nextAccessToken ?? accessToken;
  refreshToken = nextRefreshToken ?? refreshToken;

  if (nextAccessToken) {
    await setItem('accessToken', nextAccessToken);
  }

  if (nextRefreshToken) {
    await setItem('refreshToken', nextRefreshToken);
  }
}

export async function clearTokens() {
  accessToken = null;
  refreshToken = null;
  await deleteItem('accessToken');
  await deleteItem('refreshToken');
}

api.interceptors.request.use(async (config) => {
  if (!accessToken) {
    await loadStoredTokens();
  }

  if (accessToken) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${accessToken}`;
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (
      error.response?.status === 401 &&
      !originalRequest?._retry &&
      refreshToken
    ) {
      originalRequest._retry = true;

      try {
        const response = await axios.post(`${BASE_URL}/auth/refresh`, {
          refreshToken,
        });

        const newAccessToken = response.data.data.accessToken;

        await persistTokens(newAccessToken, refreshToken);

        originalRequest.headers = originalRequest.headers || {};
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;

        return api(originalRequest);
      } catch (refreshError) {
        await clearTokens();
      }
    }

    return Promise.reject(error);
  }
);

// -------------------------
// AUTH HELPERS
// -------------------------
export async function registerUser(payload = {}) {
  const normalizedPayload = {
    fullName: payload.fullName ?? payload.name ?? payload.full_name ?? '',
    email: payload.email ?? '',
    password: payload.password ?? '',
  };

  const response = await api.post('/auth/register', normalizedPayload);
  return response.data.data;
}

export async function loginUser(payload = {}) {
  const normalizedPayload = {
    email: payload.email ?? '',
    password: payload.password ?? '',
  };

  const response = await api.post('/auth/login', normalizedPayload);
  const data = response.data.data;

  if (data?.accessToken || data?.refreshToken) {
    await persistTokens(data.accessToken, data.refreshToken);
  }

  return data;
}

export async function logoutUser() {
  if (!refreshToken) {
    await loadStoredTokens();
  }

  if (refreshToken) {
    try {
      await api.post('/auth/logout', { refreshToken });
    } catch (error) {
      // αγνόησε σφάλμα logout API αλλά καθάρισε local tokens
    }
  }

  await clearTokens();
}

// -------------------------
// DATA API
// -------------------------
export async function getTheatres(filters = {}) {
  const response = await api.get('/theatres', { params: filters });
  return response.data.data;
}

export async function getShows(filters = {}) {
  const response = await api.get('/shows', { params: filters });
  return response.data.data;
}

export async function getShowtimes(showId) {
  const response = await api.get('/showtimes', { params: { showId } });
  return response.data.data;
}

export async function getSeats(showtimeId) {
  const response = await api.get('/seats', { params: { showtimeId } });
  return response.data.data;
}

export async function createReservation(payload) {
  const response = await api.post('/reservations', payload);
  return response.data.data;
}

export async function updateReservation(id, payload) {
  const response = await api.put(`/reservations/${id}`, payload);
  return response.data.data;
}

export async function cancelReservation(id) {
  const response = await api.delete(`/reservations/${id}`);
  return response.data;
}

export async function getMyReservations() {
  const response = await api.get('/user/reservations');
  return response.data.data;
}

export async function getMyProfile() {
  const response = await api.get('/user/profile');
  return response.data.data;
}

export default api;